__author__ = 'Alon Reznik'
__license__ = 'Mozilla'
__version__ = '1.3'